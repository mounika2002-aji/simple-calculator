#2Q.Write a Python program to convert a list to a tuple.
# Input:
listx = [5, 10, 7, 4, 15,3]
print(listx)

